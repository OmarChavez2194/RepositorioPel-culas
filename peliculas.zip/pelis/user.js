const mongoose = require('mongoose'); // Importa mongoose para la comunicación con MongoDB
const bcrypt = require('bcrypt'); // Importa bcrypt para el hashing seguro de contraseñas

// Define el esquema de usuario utilizando mongoose.Schema
const UserSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // Campo de nombre de usuario, requerido y único
    password: { type: String, required: true } // Campo de contraseña, requerido
});

// Middleware pre-save para hash de la contraseña antes de guardarla en la base de datos
UserSchema.pre('save', async function(next) {
    if (this.isModified('password')) { // Verifica si la contraseña ha sido modificada
        const salt = await bcrypt.genSalt(10); // Genera un salt para el hash
        this.password = await bcrypt.hash(this.password, salt); // Hashea la contraseña
    }
    next(); // Llama al siguiente middleware
});

// Método personalizado para verificar si la contraseña es correcta
UserSchema.methods.isCorrectPassword = async function(password) {
    return await bcrypt.compare(password, this.password); // Compara la contraseña proporcionada con la almacenada en la base de datos
};

// Exporta el modelo de usuario creado a partir del esquema
module.exports = mongoose.model('User', UserSchema);

// Importación de Mongoose para la conexión a la base de datos MongoDB
const mongoose = require('mongoose');
// Importación de bcrypt para el hash de contraseñas
const bcrypt = require('bcrypt');

// Definición del esquema para el administrador
const adminSchema = new mongoose.Schema({
    username: { type: String, unique: true, required: true }, // Nombre de usuario único y obligatorio
    password: { type: String, required: true } // Contraseña obligatoria
});

// Antes de guardar el admin en la base de datos, hasheamos la contraseña
adminSchema.pre('save', async function(next) {
    try {
        // Hash de la contraseña con un coste de 10
        const hashedPassword = await bcrypt.hash(this.password, 10);
        this.password = hashedPassword; // Asignación de la contraseña hasheada al campo correspondiente
        next(); // Continuar con el siguiente middleware o función
    } catch (error) {
        next(error); // Pasar el error al siguiente middleware o función
    }
});

// Método para verificar si la contraseña es correcta
adminSchema.methods.isCorrectPassword = async function(password) {
    try {
        // Comparación de la contraseña proporcionada con la contraseña almacenada en la base de datos
        return await bcrypt.compare(password, this.password);
    } catch (error) {
        throw error; // Lanzar el error si ocurre alguno durante la comparación
    }
};

// Creación del modelo Admin utilizando el esquema definido
const Admin = mongoose.model('Admin', adminSchema);

// Exportación del modelo Admin para su uso en otras partes de la aplicación
module.exports = Admin;

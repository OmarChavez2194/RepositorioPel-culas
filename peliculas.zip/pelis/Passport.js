const passport = require('passport'); // Importa el módulo Passport para la autenticación de usuarios
const LocalStrategy = require('passport-local').Strategy; // Importa la estrategia de autenticación local de Passport
const bcrypt = require('bcrypt'); // Importa bcrypt para el hashing seguro de contraseñas
const User = require('./user'); // Importa el modelo de usuario
const Admin = require('./admin'); // Importa el modelo de administrador

// Configuración de Passport para la autenticación de usuarios
passport.use('user', new LocalStrategy(async (username, password, done) => {
    try {
        const user = await User.findOne({ username }); // Busca un usuario por su nombre de usuario
        if (!user) {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' }); // Si no se encuentra el usuario, devuelve un mensaje de error
        }
        const isCorrectPassword = await user.isCorrectPassword(password); // Verifica si la contraseña es correcta utilizando el método personalizado definido en el modelo de usuario
        if (isCorrectPassword) {
            return done(null, user); // Si la contraseña es correcta, autentica al usuario
        } else {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' }); // Si la contraseña es incorrecta, devuelve un mensaje de error
        }
    } catch (error) {
        return done(error); // Si ocurre un error, devuelve el error
    }
}));

// Configuración de Passport para la autenticación de administradores
passport.use('admin', new LocalStrategy(async (username, password, done) => {
    try {
        const admin = await Admin.findOne({ username }); // Busca un administrador por su nombre de usuario
        if (!admin) {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' }); // Si no se encuentra el administrador, devuelve un mensaje de error
        }
        const isCorrectPassword = await bcrypt.compare(password, admin.password); // Compara la contraseña proporcionada con la almacenada en la base de datos para el administrador
        if (isCorrectPassword) {
            return done(null, admin); // Si la contraseña es correcta, autentica al administrador
        } else {
            return done(null, false, { message: 'Usuario y/o contraseña incorrecta' }); // Si la contraseña es incorrecta, devuelve un mensaje de error
        }
    } catch (error) {
        return done(error); // Si ocurre un error, devuelve el error
    }
}));

// Serializa al usuario/administrador para almacenar en la sesión
passport.serializeUser((user, done) => {
    done(null, user.id); // Serializa al usuario/administrador por su ID
});

// Deserializa al usuario/administrador a partir de su ID almacenado en la sesión
passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id); // Busca al usuario por su ID
        if (user) {
            return done(null, user); // Si se encuentra el usuario, lo devuelve
        }
        const admin = await Admin.findById(id); // Busca al administrador por su ID
        return done(null, admin); // Si se encuentra el administrador, lo devuelve
    } catch (error) {
        return done(error); // Si ocurre un error, devuelve el error
    }
});

module.exports = passport; // Exporta Passport para su uso en otras partes de la aplicación

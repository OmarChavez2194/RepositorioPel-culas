const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PeliculasSchema = new Schema({
    titulo: {
        type: String,
        required: true
    },
    anio: {
        type: Number,
        required: true
    },
    director: {
        type: String,
        required: true
    },
    actores: {
        type: [String],
        required: true
    },
    imagen: {
        type: String, // Este campo debe ser una URL
        required: true
    },
    usuario: {
        type: Schema.Types.ObjectId,
        ref: 'User' // Referencia al modelo de usuario
    }
});

const Peliculas = mongoose.model('Peliculas', PeliculasSchema);

module.exports = Peliculas;

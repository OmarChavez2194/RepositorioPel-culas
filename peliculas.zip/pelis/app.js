// Importación de módulos necesarios
const express = require('express'); // Importa Express, un framework web para Node.js
const path = require('path'); // Importa el módulo 'path' para manejar rutas de archivos y directorios
const bcrypt = require('bcrypt'); // Importa bcrypt para el hashing seguro de contraseñas
const mongoose = require('mongoose'); // Importa mongoose para la comunicación con MongoDB
const session = require('express-session'); // Importa express-session para la gestión de sesiones de usuario
const passport = require('./Passport'); // Importa la configuración de Passport para la autenticación
const User = require('./user'); // Importa el modelo de usuario
const Admin = require('./admin'); // Importa el modelo de administrador
const Peliculas = require('./peliculas'); // Importa el modelo de películas

const app = express(); // Inicializa Express

const mongo_uri = 'mongodb://localhost:27017/usuarios'; // URI de conexión a MongoDB

// Conexión a MongoDB
mongoose.connect(mongo_uri, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log(`Successfully connected to ${mongo_uri}`); // Mensaje de conexión exitosa
        app.listen(3000, () => {
            console.log('Server started on port 3000'); // Mensaje de inicio del servidor
        });
    })
    .catch(err => {
        console.error('Error connecting to MongoDB:', err); // Mensaje de error en la conexión a MongoDB
    });

// Ruta para la página de inicio
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'inicio.html')); // Envía el archivo de inicio al cliente
});

// Ruta para la página de administrador
app.get('/administrador', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.sendFile(path.join(__dirname, 'public', 'indexadm.html')); // Envía la página de administrador si está autenticado y es administrador
    } else {
        res.redirect('/login'); // Redirige a la página de inicio de sesión si no está autenticado o no es administrador
    }
});

// Ruta para la página de registro de administrador
app.get('/signupadm', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.sendFile(path.join(__dirname, 'public', 'signupadm.html')); // Envía la página de registro de administrador si está autenticado y es administrador
    } else {
        res.redirect('/login'); // Redirige a la página de inicio de sesión si no está autenticado o no es administrador
    }
});

// Middleware para servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Middleware para el manejo de datos JSON
app.use(express.json());

// Middleware para el análisis de datos codificados en la URL
app.use(express.urlencoded({ extended: false }));

// Configuración de la sesión
app.use(session({
    secret: 'mysecretkey', // Clave secreta para firmar la cookie de sesión
    resave: true, // Vuelve a guardar la sesión en el almacén aunque no haya cambios
    saveUninitialized: true // Guarda una sesión nueva aunque no haya sido inicializada
}));

// Inicialización de Passport
app.use(passport.initialize());
app.use(passport.session());

// Middleware para serializar el usuario en la sesión
passport.serializeUser((user, done) => {
    done(null, user); // Serializa el usuario actual
});

// Middleware para deserializar el usuario de la sesión
passport.deserializeUser((obj, done) => {
    done(null, obj); // Deserializa el usuario actual
});

// Ruta para verificar si el usuario es administrador
app.get('/checkadmin', (req, res) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        res.json({ esAdmin: true }); // Responde con un objeto indicando si el usuario es administrador
    } else {
        res.json({ esAdmin: false }); // Responde con un objeto indicando que el usuario no es administrador
    }
});

// Rutas de autenticación de usuario
app.post('/authenticate', passport.authenticate('user', {
    successRedirect: '/princi.html', // Redirige al usuario a esta página si la autenticación es exitosa
    failureRedirect: '/', // Redirige al usuario a la página de inicio si la autenticación falla
    failureFlash: true // Activa el uso de mensajes flash para notificar errores de autenticación
}));

// Rutas de autenticación de administrador
app.post('/authenticateadmin', passport.authenticate('admin', {
    successRedirect: '/princi.html', // Redirige al administrador a esta página si la autenticación es exitosa
    failureRedirect: '/administrador', // Redirige al administrador a la página de administrador si la autenticación falla
    failureFlash: true // Activa el uso de mensajes flash para notificar errores de autenticación
}));

// Middleware para verificar si el usuario es administrador
const isAdmin = (req, res, next) => {
    if (req.isAuthenticated() && req.user instanceof Admin) {
        next(); // Si el usuario es administrador, pasa al siguiente middleware
    } else {
        res.status(403).send('Acceso denegado. Debes ser administrador para acceder a esta función'); // Si no es administrador, responde con un mensaje de acceso denegado
    }
};

// Ruta para guardar película
app.post('/guardarpelicula', async (req, res) => {
    const { titulo, anio, director, actores, imagen } = req.body; // Extrae los datos de la solicitud
    const usuarioId = req.user._id; // Obtiene el ID del usuario o administrador autenticado

    console.log('Datos recibidos para guardar la película:', { titulo, anio, director, actores, imagen }); // Muestra los datos recibidos en la consola

    try {
        const pelicula = new Peliculas({ titulo, anio, director, actores, imagen, usuario: usuarioId }); // Crea una nueva instancia de Peliculas con los datos recibidos
        await pelicula.save(); // Guarda la película en la base de datos
        console.log('Película guardada en la base de datos:', pelicula); // Muestra un mensaje de éxito en la consola
        res.redirect('/princi.html'); // Redirige a la página principal
    } catch (error) {
        console.error('Error al guardar la película:', error); // Muestra un mensaje de error en la consola
        res.status(500).send('ERROR AL GUARDAR LA PELÍCULA'); // Responde con un mensaje de error al cliente
    }
});

// Ruta para obtener todas las películas
app.get('/api/peliculas', async (req, res) => {
    try {
        const peliculas = await Peliculas.find().populate('usuario'); // Obtiene todas las películas de la base de datos con el usuario asociado
        res.json(peliculas); // Responde con las películas en formato JSON
    } catch (error) {
        console.error('Error al obtener películas:', error); // Muestra un mensaje de error en la consola
        res.status(500).send('ERROR AL OBTENER LAS PELÍCULAS'); // Responde con un mensaje de error al cliente
    }
});

// Ruta para eliminar una película, solo para administradores
app.delete('/eliminarPelicula/:id', isAdmin, async (req, res) => {
    const peliculaId = req.params.id; // Obtiene el ID de la película a eliminar
    
    try {
        const peliculaEliminada = await Peliculas.findByIdAndDelete(peliculaId); // Busca y elimina la película de la base de datos
        console.log('Película eliminada:', peliculaEliminada); // Muestra un mensaje de éxito en la consola
        res.status(200).send('Película eliminada exitosamente'); // Responde con un mensaje de éxito al cliente
    } catch (error) {
        console.error('Error al eliminar película:', error); // Muestra un mensaje de error en la consola
        res.status(500).send('Error al eliminar la película'); // Responde con un mensaje de error al cliente
    }
});

// Rutas de autenticación de usuario
app.post('/register', async (req, res) => {
    const { username, password } = req.body; // Extrae los datos de la solicitud
    console.log('Datos recibidos en el registro:', { username, password }); // Muestra los datos recibidos en la consola
    try {
        const user = new User({ username, password }); // Crea una nueva instancia de User con los datos recibidos
        await user.save(); // Guarda el usuario en la base de datos
        console.log('Usuario registrado en la base de datos:', user); // Muestra un mensaje de éxito en la consola
        res.sendFile(path.join(__dirname, 'public', 'index.html')); // Redirige al usuario a la página principal
    } catch (error) {
        console.error('Error al registrar usuario:', error); // Muestra un mensaje de error en la consola
        if (error.name === 'MongoError' && error.code === 11000 && error.keyPattern && error.keyPattern.username === 1) {
            res.status(400).send('El nombre de usuario ya está en uso'); // Responde con un mensaje de error si el nombre de usuario ya está en uso
        } else {
            res.status(500).send('ERROR AL REGISTRAR AL USUARIO'); // Responde con un mensaje de error genérico
        }
    }
});

// Rutas de autenticación de administrador
app.post('/registeradmin', async (req, res) => {
    const { username, password } = req.body; // Extrae los datos de la solicitud
    console.log('Datos recibidos en el registro de administrador:', { username, password }); // Muestra los datos recibidos en la consola
    try {
        const admin = new Admin({ username, password }); // Crea una nueva instancia de Admin con los datos recibidos
        await admin.save(); // Guarda el administrador en la base de datos
        console.log('Administrador registrado en la base de datos:', admin); // Muestra un mensaje de éxito en la consola
        res.sendFile(path.join(__dirname, 'public', 'indexadm.html')); // Redirige al administrador a la página principal de administrador
    } catch (error) {
        console.error('Error al registrar administrador:', error); // Muestra un mensaje de error en la consola
        if (error.name === 'MongoError' && error.code === 11000 && error.keyPattern && error.keyPattern.username === 1) {
            res.status(400).send('El nombre de administrador ya está en uso'); // Responde con un mensaje de error si el nombre de administrador ya está en uso
        } else {
            res.status(500).send('ERROR AL REGISTRAR AL ADMINISTRADOR'); // Responde con un mensaje de error genérico
        }
    }
});

module.exports = app; // Exporta la aplicación Express
